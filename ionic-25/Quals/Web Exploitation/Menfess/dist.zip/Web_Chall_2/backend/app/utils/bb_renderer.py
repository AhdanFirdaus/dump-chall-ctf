import re
import bbcode

class BBRenderer:
    def __init__(self):
        parser = bbcode.Parser()
        parser.add_formatter("youtube", self._fmt_youtube, standalone=True)
        parser.add_formatter("yt", self._fmt_youtube, standalone=True)
        parser.add_formatter("img", self._fmt_image, replace_links=False)
        parser.add_simple_formatter("h1", "<h1>%(value)s</h1>")
        parser.add_simple_formatter("sup", "<sup>%(value)s</sup>")
        self.parser = parser

    def render(self, content: str) -> str:
        return self.parser.format(content)

    @staticmethod
    def _sanitize_options(opts: dict) -> None:
        escape_parser = bbcode.Parser()
        for k, v in list(opts.items()):
            clean_val = escape_parser._replace(v, escape_parser.REPLACE_ESCAPE)
            proto = re.sub(r"[^a-z0-9+]", "", clean_val.lower().split(":", 1)[0])
            if proto in ("javascript", "data", "vbscript"):
                opts[k] = "undefined"
            else:
                opts[k] = clean_val

    @classmethod
    def _fmt_youtube(cls, tag_name, value, options, parent, context):
        yt = {
            "youtube_id": options.get("id", "dQw4w9WgXcQ"),
            "width": options.get("width", "670"),
            "height": options.get("height", "420"),
        }
        cls._sanitize_options(yt)
        return (
            f'<iframe width="{yt["width"]}" height="{yt["height"]}" '
            f'src="https://www.youtube.com/embed/{yt["youtube_id"]}" '
            f'frameborder="0" allowfullscreen></iframe>'
        )

    @classmethod
    def _fmt_image(cls, tag_name, value, options, parent, context):
        img_attr = {}
        if "width" in options:
            img_attr["width"] = options["width"]
        if "height" in options:
            img_attr["height"] = options["height"]

        cls._sanitize_options(img_attr)

        attr_parts = []
        for k, v in img_attr.items():
            if isinstance(v, str) and " " in v:
                first, after = v.split(" ", 1)
                attr_parts.append(f'{k}="{first}" {after}')
            else:
                attr_parts.append(f'{k}="{v}"')

        attr_str = " ".join(attr_parts)

        safe_src = value.replace('"', "%22")

        return (
            f'<img src="{safe_src}" {attr_str} '
            'alt="Posted image" style="max-width:100%;">'
        )
