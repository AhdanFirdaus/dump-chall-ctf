# Menfess

by chitanda

---

## Description
Ini hanyalah website menfess biasa, tempat mencurahkan isi hati para mahasiswa yang sudah burnout karena laprak dan sebagainya. Namun pernahkah kamu tau bagaimana isi hati yang terdalam dari sang "Penilik" yang tak mau terlihat? 

## Difficulty
easy

## Deployment
**Build and run with Docker Compose:**
   ```bash
   docker-compose up --build
   ```
- Website berjalan di port **80**
- Bot berjalan di port **5001**

## Notes
Ketika testing di local dengan docker compose, gunakan host **http://nginx/*** saat submit ke bot (ganti localhost menjadi nginx).

## Flag Format
`IONIC{flag}`

## Attachment
- ./web_chall_2-dist.zip

Selamat Berjuang! Sukses 🚩
