from flask import Flask, request, render_template
import subprocess
import re

app = Flask(__name__)


@app.route("/", methods=["GET", "POST"])
def index():
    output = None
    if request.method == "POST":
        host = request.form.get("host", "")

        blacklist = ["|", "&", " ", "`", "cat", "&&"]
        if any(bad in host for bad in blacklist):
            output = "Hengker detected 🚨"
        else:
            cmd = f"ping -c 1 {host}"
            try:
                subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                output = "Done!"
            except Exception as e:
                output = f"Error: {str(e)}"

    return render_template("index.html", output=output)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

